// scripts.js
document.addEventListener('DOMContentLoaded', function() {
    const elementsToAnimate = document.querySelectorAll('.animate-me');

    elementsToAnimate.forEach(element => {
        element.classList.add('fade-in');
    });
});
