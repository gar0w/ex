from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

app_name = 'users'

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('home/', views.home, name='home'),
    path('perfil/', views.perfil, name='perfil'),
    path('settings/', views.settings_view, name='settings'),
    path('scan_qr/', views.scan_qr, name='scan_qr'),
    path('save_attendance/', views.save_attendance, name='save_attendance'),
    path('attendance_success/', views.attendance_success, name='attendance_success'),
    path('generate_qr/', views.generate_qr, name='generate_qr'),
    path('send_qr/', views.send_qr, name='send_qr'),
    path('download_qr/', views.download_qr, name='download_qr'),
    path('report/', views.report, name='report'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
