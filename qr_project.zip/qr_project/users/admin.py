from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, Attendance

class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('user_type', 'id_number', 'date_of_birth', 'qr_code', 'is_present')}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        (None, {'fields': ('user_type', 'id_number', 'date_of_birth', 'qr_code', 'is_present')}),
    )

admin.site.register(CustomUser, CustomUserAdmin)
admin.site.register(Attendance)
